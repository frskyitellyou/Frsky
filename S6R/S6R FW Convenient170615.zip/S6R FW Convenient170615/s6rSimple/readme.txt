2017.6.15
      1. fix the RSSI issue
2017.5.16
      1.add config convenient Mode
      2.defualt mode is simpleMode
      3.In Convenient Mode:
            channel10 <mid     starter mode
                     =mid     middle mode
                     >mid     export
      4.when throttle is low,channel12 has passed mid  two times in 3s,will enter selfcheck mode.
      5.when channel12 >mid,enter ugernt mode.
      6.blue led will flash 3s when power on in convenient Mode. 
      7.pc config version 1.6
2017.3.30
  1. when ail2/ele2 set to aux,it will no output  when self test completed
2017.2.17
  1.fix no use when vibrate is strong
  2.can be recovered when the engine is ignited
2016.12.26
  1.fix the bug of jump of channel 5--8
2016.12.23
  1. channel pass midpoint 3 times in 3 seconds will enter self-check
  2.pc config add load and save config file

2016.12.20
--1.In DELTA,the rudder stabilisation will have no effect when ch10 in the center.

2016.12.19
--1.change the way into self-check: 
    Ch12 continuously switches to midpoint 5 times within 5 s


2016.12.16
--1.RF adapt to DH16V2
--2.self check will start when ch12 move to centre long than 1s.


2016.12.12
1.Channel AUX1 or AIL2,AUX2 or ELE2 can be selected in S6R.
2.Fix crc bugs in s6r/stk/pcconfig
3.Message queue will be reset when time out in STK.  \
4.Rud with stablization  in delta wing mod

note:s6r/stk/pc config/lua script all need update.
