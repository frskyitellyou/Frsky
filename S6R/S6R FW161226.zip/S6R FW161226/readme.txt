readme
1. Fix the bug of jump of channel 5-8
2. Channel pass midpoint 3 times in 3 seconds will enter self-check
3. PC config add load and save config file
4. In DELTA, the rudder stabilization will have no effect when CH10 in the center
5. RF adapt to DH16V2
6. Channel AUX1 or AIL2, AUX2 or ELE2 can be selected in S6R
7. Fix CRC bugs in S6R/STK/PC config
8. Message queue will be reset when time out in STK
9. Rud with stablization in delta wing mod

Note: S6R/STK/PC config/Lua script all need update